﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace BookAddition.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class LibrarySystemController : ControllerBase
    {
        List<LibraryDataTypes> libraryStats = new List<LibraryDataTypes>
        {
            new LibraryDataTypes {BookName="No Echo",Category="Mystery", Price=13.63, ShelfNumber=102},
            new LibraryDataTypes {BookName="The Bell Jar",Category="Psychological Fiction", Price=14.99, ShelfNumber=104 },
            new LibraryDataTypes {BookName="Ethan Frome",Category="Horror Fiction", Price=9.79, ShelfNumber=103 },
            new LibraryDataTypes {BookName="The Communist Manifesto",Category="Non-fiction", Price=3.0, ShelfNumber=101 },
            new LibraryDataTypes {BookName="SuperIntelligence: Paths, Dangers, Strategies",Category="Dissertion", Price=18.49, ShelfNumber=105 },
                        new LibraryDataTypes {BookName="The Blind Owl",Category="Novel", Price=12.49, ShelfNumber=106},
            new LibraryDataTypes {BookName="The Little Black Fish",Category="Fiction", Price=13.33, ShelfNumber=107 },
            new LibraryDataTypes {BookName="Symphony of the Dead",Category="Historical Fiction", Price=9.0, ShelfNumber=108 },
            new LibraryDataTypes {BookName="Missing Soluch",Category="Political Fiction", Price=7.47, ShelfNumber=109 },
            new LibraryDataTypes {BookName="Her Eyes",Category="Drama", Price=279.95, ShelfNumber=110 },
                        new LibraryDataTypes {BookName="Madonna in a Fur Coat",Category="Novel", Price=11.70, ShelfNumber=111},
            new LibraryDataTypes {BookName="My Name Is Red",Category="Historical Novel", Price=8.99, ShelfNumber=112 },
            new LibraryDataTypes {BookName="The White Castle",Category="Novel", Price=15.99, ShelfNumber=113 },
            new LibraryDataTypes {BookName="Last train to Istanbul",Category="War Story", Price=10.99, ShelfNumber=114 },
            new LibraryDataTypes {BookName="SuperIntelligence: Paths, Dangers, Strategies",Category="Dissertion", Price=18.49, ShelfNumber=115 },
                        new LibraryDataTypes {BookName="No Echo",Category="Mystery", Price=13.63, ShelfNumber=116},
            new LibraryDataTypes {BookName="The Bell Jar",Category="Psychological Fiction", Price=14.99, ShelfNumber=117 },
            new LibraryDataTypes {BookName="Ethan Frome",Category="Horror Fiction", Price=9.79, ShelfNumber=118 },
            new LibraryDataTypes {BookName="The Communist Manifesto",Category="Non-fiction", Price=3.0, ShelfNumber=119 },
            new LibraryDataTypes {BookName="SuperIntelligence: Paths, Dangers, Strategies",Category="Dissertion", Price=18.49, ShelfNumber=120 }
        };

        private readonly ILogger<LibrarySystemController> _logger;

        public LibrarySystemController(ILogger<LibrarySystemController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public List<LibraryDataTypes> Get()
        {
            return libraryStats;
        }
        [Route("names")]
        public List<string> GetNames()
        {
            var booksQuery =
                from book in libraryStats
                select book.BookName;
            return booksQuery.ToList();
        }
        [Route("detail/{name}")]
        public LibraryDataTypes GetDetail(string name)
        {
            IEnumerable<LibraryDataTypes> booksQuery =
                from book in libraryStats
                where book.BookName == name
                select book;
            return booksQuery.FirstOrDefault();
        }

        [Route("post")]
        [HttpPost]
        public List<LibraryDataTypes> AddNewBook([FromBody] LibraryDataTypes addNewBook)
        {
            libraryStats.Add(addNewBook);
            return libraryStats;
        }
        [HttpPut]
        [Route("update/{name}")]
        public List<LibraryDataTypes> UpdateDetail(string name, [FromBody] LibraryDataTypes addNewBook)
        {
            foreach (var book in libraryStats) 
            {
                if (name == book.BookName)
                {
                    book.BookName = addNewBook.BookName;
                    book.Category = addNewBook.Category;
                    book.Price = addNewBook.Price;
                    book.ShelfNumber = addNewBook.ShelfNumber;
                }
            }
            return libraryStats;
        }
    }
}
