--Task1
CREATE TABLE Weather(
	id int NOT NULL PRIMARY KEY IDENTITY(1,1),
	recordDate date,
	temperature int
);
SELECT * from Weather
--Task2
CREATE TABLE weather_details(
	Desc_id int NOT NULL PRIMARY KEY IDENTITY(1,1),
	tempID int FOREIGN KEY REFERENCES Weather(id),
	Description varchar(255)
);
SELECT * from weather_details
--Task3
EXEC sp_RENAME 'weather_details.tempID','temperatureID','COLUMN'
SELECT * from weather_details
--Task4
INSERT INTO Weather(id,recordDate,temperature)
VALUES ((101,),(),());