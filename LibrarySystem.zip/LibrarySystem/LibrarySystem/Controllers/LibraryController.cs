﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BooksData.Interfaces;
using BooksData.Repositories;
using BooksData.Models;

namespace LibrarySystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LibraryController : ControllerBase
    {
        private  BooksDataRep books = new BooksDataRep();
        private UsersDataRep users = new UsersDataRep();
        [HttpGet]
        public List<UnitBook> GetBooks()
        {
            return books.GetBooksData();
        }
        [Route("users")]
        public ActionResult<IEnumerable<UnitUser>> GetUsers()
        {
            return users.GetUsersData();
        }
        [Route("booksNames")]
        public List<string> GetNames()
        {
            return books.GetBooksNamesData();
        }
        [Route("bookDetail/{bookname}")]
        public Tuple<UnitBook, string> GetBookDetailData(string bookname)
        {
            return new Tuple<UnitBook, string>(books.GetBookDetailData(bookname), users.GetBookUserData(bookname));
        }
        [Route("userDetail/{username}")]
        public UnitUser GetUserDetailData(string username)
        {
            return users.GetUserDetailData(username);
        }
        [HttpPost]
        [Route("postUser")]
        public List<UnitUser> AddNewUser([FromBody] UnitUser addNewUser)

        {
            return users.InsertUsersData(addNewUser);
        }
        [Route("postBook")]
        public List<UnitBook> AddNewBook([FromBody] UnitBook addNewBook)

        {
            return books.InsertBooksData(addNewBook);
        }
    }
}