﻿using BooksData.Interfaces;
using BooksData.Models;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;

namespace BooksData.Repositories
{
    public class UsersDataRep : IUsers
    {
        public List<UnitUser> UsersStats = new List<UnitUser>
        {
            new UnitUser {ID="1",Name="User1", BookIssuedList= {"Book20" } },
            new UnitUser {ID="2",Name="User2", BookIssuedList={ "Book2", "Book3" } },
            new UnitUser {ID="3",Name="User3", BookIssuedList={ "Book4", "Book5" } },
            new UnitUser {ID="4",Name="User4", BookIssuedList={ "Book5", "Book7" } },
            new UnitUser {ID="5",Name="User5", BookIssuedList={ "Book8", "Book9" } },
            new UnitUser {ID="6",Name="User6", BookIssuedList={ "Book10", "Book11", } },
            new UnitUser {ID="7",Name="User7", BookIssuedList={ "Book12", "Book13" } },
            new UnitUser {ID="8",Name="User8", BookIssuedList={ "Book14", "Book15" } },
            new UnitUser {ID="9",Name="User9", BookIssuedList={ "Book16", "Book17" } },
            new UnitUser {ID="10",Name="User10", BookIssuedList={ "Book1", "Book18", } }
        };
        public List<UnitUser> GetUsersData()
        {
            return UsersStats;
        }
        public List<UnitUser> InsertUsersData(UnitUser insertUserData)
        {
            UsersStats.Add(insertUserData);
            return UsersStats;
        }
        public string GetBookUserData(string bookname)
        {
            foreach (var usr in UsersStats)
            {
                foreach (var bookIssued in usr.BookIssuedList)
                {
                    if (bookIssued == bookname)
                    {
                        return "Issued by " + usr.Name;
                    }
                }
            }
            return "Not Issued";
        }
        public UnitUser GetUserDetailData(string username)
        {
            IEnumerable<UnitUser> UsersQuery =
                from user in UsersStats
                where user.Name == username
                select user;
            return UsersQuery.FirstOrDefault();

        }
    }
}
