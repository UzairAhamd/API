﻿using BooksData.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace BooksData.Interfaces
{
    public interface IBooks
    {
        public List<UnitBook> GetBooksData();
        //public int InsertBooksData(BooksDataTypes insertWeatherData);
        //public int UpdateBooksData(int weatherUpdateIndex, BooksDataTypes weatherUpdateInput);
        //public int DeleteBooksData(int weatherDeleteIndex);
        public List<string> GetBooksNamesData();

        public UnitBook GetBookDetailData(string bookname);
        public List<UnitBook> InsertBooksData(UnitBook insertBookData);
    }
}
