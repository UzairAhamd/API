﻿using BooksData.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace BooksData.Interfaces
{
    public interface IUsers
    {
        public List<UnitUser> GetUsersData();
        public List<UnitUser> InsertUsersData(UnitUser insertUserData);
        public string GetBookUserData(string bookname);
        public UnitUser GetUserDetailData(string username);
    }
}
