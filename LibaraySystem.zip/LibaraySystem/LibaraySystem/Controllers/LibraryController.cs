﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BooksStore.Interfaces;
using BooksData.Repositories;
using BooksStore.Repositories;
using BookStore.Models;

namespace LibrarySystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LibraryController : ControllerBase
    {
        private BooksDataRep books = new BooksDataRep();
        private UsersDataRep users = new UsersDataRep();
        [HttpGet]
        public List<UnitBook> GetBooks()
        {
            return books.GetBooksData();
        }
        [Route("users")]
        public ActionResult<IEnumerable<UnitUser>> GetUsers()
        {
            return users.GetUsersData();
        }
        [Route("booksNames")]
        public List<string> GetNames()
        {
            return books.GetBooksNamesData();
        }
        [Route("bookDetail/{bookname}")]
        public Tuple<UnitBook, string> GetBookDetailData(string bookname)
        {
            return new Tuple<UnitBook, string>(books.GetBookDetailData(bookname), users.GetBookUserData(bookname));
        }
        [Route("userDetail/{username}")]
        public UnitUser GetUserDetailData(string username)
        {
            return users.GetUserDetailData(username);
        }
        [HttpPost]
        [Route("postUser")]
        public List<UnitUser> AddNewUser([FromBody] UnitUser addNewUser)

        {
            return users.InsertUsersData(addNewUser);
        }
        [Route("postBook")]
        public List<UnitBook> AddNewBook([FromBody] UnitBook addNewBook)

        {
            return books.InsertBooksData(addNewBook);
        }
        [HttpPut]
        [Route("book/{bookUpdateName}")]
        public List<UnitBook> UpdateBook(string bookUpdateName, [FromBody] UnitBook bookUpdateInput)
        {
            books.UpdateBookData(bookUpdateName, bookUpdateInput);
            return books.GetBooksData();
        }
        [Route("user/{userUpdateID}")]
        public List<UnitUser> UpdateUser(string userUpdateID, [FromBody] UnitUser userUpdateInput)
        {
            users.UpdateUserData(userUpdateID, userUpdateInput);
            return users.GetUsersData();
        }
        [Route("userIssue/{userIssueID}")]
        public string IssueBookToUser(string userName, [FromBody] string issueBook)
        {
            return users.IssueBookToUserData(userName, issueBook);
        }
        [HttpDelete]
        [Route("bookdel/{BookDeleteName}")]
        public Tuple<string, string> DeleteBook(string BookDeleteName)
        {
            return new Tuple<string, string>(books.DeleteBookData(BookDeleteName),users.DeleteBookFromUserData(BookDeleteName));
        }
        [Route("userdel/{UserDeleteID}")]
        public string DeleteUser(string UserDeleteID)
        {
            return users.DeleteUserData(UserDeleteID);

        }
        [Route("return/{BookReturnName}")]
        public string RemoveReturnBook(string BookReturnName)
        {
            return users.RemoveReturnBookData(BookReturnName);

        }
    }
}