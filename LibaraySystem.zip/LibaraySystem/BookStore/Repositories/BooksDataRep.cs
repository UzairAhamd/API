﻿using BooksStore.Interfaces;
using BookStore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BooksStore.Repositories
{
    public class BooksDataRep : IBooks
    {
        public List<UnitBook> libraryStats = new List<UnitBook>
        {
            new UnitBook {BookName="Book1",Category="Mystery", Price=13.63, ShelfNumber=102},
            new UnitBook {BookName="Book2",Category="Psychological Fiction", Price=14.99, ShelfNumber=104 },
            new UnitBook {BookName="Book3",Category="Horror Fiction", Price=9.79, ShelfNumber=103 },
            new UnitBook {BookName="Book4",Category="Non-fiction", Price=3.0, ShelfNumber=101 },
            new UnitBook {BookName="Book5",Category="Dissertion", Price=18.49, ShelfNumber=105 },
                        new UnitBook {BookName="Book6",Category="Novel", Price=12.49, ShelfNumber=106},
            new UnitBook {BookName="Book7",Category="Fiction", Price=13.33, ShelfNumber=107 },
            new UnitBook {BookName="Book8",Category="Historical Fiction", Price=9.0, ShelfNumber=108 },
            new UnitBook {BookName="Book9",Category="Political Fiction", Price=7.47, ShelfNumber=109 },
            new UnitBook {BookName="Book10",Category="Drama", Price=279.95, ShelfNumber=110 },
                        new UnitBook {BookName="Book11",Category="Novel", Price=11.70, ShelfNumber=111},
            new UnitBook {BookName="Book12",Category="Historical Novel", Price=8.99, ShelfNumber=112 },
            new UnitBook {BookName="Book13",Category="Novel", Price=15.99, ShelfNumber=113 },
            new UnitBook {BookName="Book14",Category="War Story", Price=10.99, ShelfNumber=114 },
            new UnitBook {BookName="Book15",Category="Dissertion", Price=18.49, ShelfNumber=115 },
                        new UnitBook {BookName="Book16",Category="Mystery", Price=13.63, ShelfNumber=116},
            new UnitBook {BookName="Book17",Category="Psychological Fiction", Price=14.99, ShelfNumber=117 },
            new UnitBook {BookName="Book18",Category="Horror Fiction", Price=9.79, ShelfNumber=118 },
            new UnitBook {BookName="Book19",Category="Non-fiction", Price=3.0, ShelfNumber=119 },
            new UnitBook {BookName="Book20",Category="Dissertion", Price=18.49, ShelfNumber=120 }
        };
        public List<UnitBook> GetBooksData()
        {
            return libraryStats;
        }
        public List<string> GetBooksNamesData()
        {
            var booksQuery =
                from book in libraryStats
                select book.BookName;
            return booksQuery.ToList();
        }
        public UnitBook GetBookDetailData(string bookname)
        {
            IEnumerable<UnitBook> booksQuery =
                from book2 in libraryStats
                where book2.BookName == bookname
                select book2;
            return booksQuery.FirstOrDefault();
        }
        public List<UnitBook> InsertBooksData(UnitBook insertBookData)
        {
            libraryStats.Add(insertBookData);
            return libraryStats;
        }
        public void UpdateBookData(string BookUpdateName, UnitBook BookUpdateData)
        {
            foreach (var book in libraryStats)
            {
                if (BookUpdateName == book.BookName)
                {
                    book.BookName = BookUpdateData.BookName;
                    book.Category = BookUpdateData.Category;
                    book.Price = BookUpdateData.Price;
                    book.ShelfNumber = BookUpdateData.ShelfNumber;
                }
            }
        }
        //to delete an issued book (partial)
        public string DeleteBookData(string BookDeleteName)
        {
            {
                foreach (var book2 in libraryStats)
                {
                    if (BookDeleteName == book2.BookName)
                    {
                        libraryStats.Remove(book2);
                        return BookDeleteName+" has been deleted from library";
                    }
                }
                return BookDeleteName + " isn't deleted from library";
            }

        }

    }
}
