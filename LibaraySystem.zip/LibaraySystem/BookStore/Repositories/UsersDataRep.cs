﻿using BookStore.Models;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using BooksStore.Interfaces;

namespace BooksData.Repositories
{
    public class UsersDataRep : IUsers
    {
        public List<UnitUser> UsersStats = new List<UnitUser>
        {
            new UnitUser {ID="A1",Name="User1", BookIssuedList=  new List<string>(){} },
            new UnitUser {ID="B2",Name="User2", BookIssuedList= new List<string>(){ "Book2", "Book3" } },
            new UnitUser {ID="C3",Name="User3", BookIssuedList= new List<string>(){ "Book4", "Book5" } },
            new UnitUser {ID="D4",Name="User4", BookIssuedList= new List<string>(){ "Book5", "Book7" } },
            new UnitUser {ID="E5",Name="User5", BookIssuedList= new List<string>(){ "Book8", "Book9" } },
            new UnitUser {ID="F6",Name="User6", BookIssuedList= new List<string>(){ "Book10", "Book11", } },
            new UnitUser {ID="A2",Name="User7", BookIssuedList= new List<string>(){ "Book12", "Book13" } },
            new UnitUser {ID="A3",Name="User8", BookIssuedList= new List<string>(){ "Book14", "Book15" } },
            new UnitUser {ID="A4",Name="User9", BookIssuedList= new List<string>(){ "Book16", "Book17" } },
            new UnitUser {ID="A5",Name="User10", BookIssuedList= new List<string>(){ "Book1", "Book18", } }
        };
        public List<UnitUser> GetUsersData()
        {
            return UsersStats;
        }
        public List<UnitUser> InsertUsersData(UnitUser insertUserData)
        {
            UsersStats.Add(insertUserData);
            return UsersStats;
        }
        public string GetBookUserData(string bookname)
        {
            foreach (var usr in UsersStats)
            {
                foreach (var bookIssued in usr.BookIssuedList)
                {
                    if (bookIssued == bookname)
                    {
                        return "Issued by " + usr.Name;
                    }
                }
            }
            return "Not Issued";
        }
        public UnitUser GetUserDetailData(string username)
        {
            IEnumerable<UnitUser> UsersQuery =
                from user in UsersStats
                where user.Name == username
                select user;
            return UsersQuery.FirstOrDefault();
        }
        public void UpdateUserData(string UserUpdateID, UnitUser UserUpdateData)
        {
            foreach (var user in UsersStats)
            {
                if (UserUpdateID == user.ID)
                {
                    user.ID = UserUpdateData.ID;
                    user.Name = UserUpdateData.Name;
                    user.BookIssuedList = UserUpdateData.BookIssuedList;
                }
            }
        }
        public string IssueBookToUserData(string userID, string issueBook)
        {
            foreach (var usr in UsersStats)
            {
                foreach (var bookIssued in usr.BookIssuedList)
                {
                    if (bookIssued == issueBook)
                    {
                        return "Issued by " + usr.Name;
                    }
                }
                foreach (var userIssued in usr.ID)
                {
                    if (userIssued.ToString() == userID)
                    {
                        usr.BookIssuedList.Add(issueBook);
                        return issueBook + " Issued to " + userID;
                    }
                }
            }
            return "Issued";
        }
        //to delete an issued book (user partial part)
        public string DeleteBookFromUserData(string BookDeleteName)
        {
            foreach (var usr in UsersStats)
            {
                foreach (var userIssued in usr.BookIssuedList)
                {
                    if (userIssued.ToString() == BookDeleteName)
                    {
                        usr.BookIssuedList.Remove(BookDeleteName);
                        return BookDeleteName + " has been removed from " + usr.ID + " issued list";
                    }
                }
            }
            return BookDeleteName + " wasn't issued by any user";
        }
        //to delete a user
        public string DeleteUserData(string UserDeleteID)
        {
            var userDeletIndex = from user in UsersStats
                                 where user.ID == UserDeleteID
                                 select UsersStats.IndexOf(user);

            if (UsersStats[userDeletIndex.FirstOrDefault()].BookIssuedList.Count != 0)
            {
                return UserDeleteID + " has issued books so can't be deleted";
            }
            else
            {
                UsersStats.Remove(UsersStats[userDeletIndex.FirstOrDefault()]);
                return UserDeleteID + " has been deleted";
            }
        }
        //to remove a book from bookIssuedList
        public string RemoveReturnBookData(string BookReturnName)
        {
            foreach (var usr in UsersStats)
            {
                foreach (var bookIssued in usr.BookIssuedList)
                {
                    if (bookIssued.ToString() == BookReturnName)
                    {
                        usr.BookIssuedList.Remove(BookReturnName);
                        return BookReturnName + " has been removed from " + usr.ID + " issued list";
                    }
                }
            }
            return BookReturnName + " wasn't issued by any user";
        }
    }
}
