﻿using BookStore.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace BooksStore.Interfaces
{
    public interface IBooks
    {
        public List<UnitBook> GetBooksData();
        //public int InsertBooksData(BooksDataTypes insertWeatherData);
        public void UpdateBookData(string BookUpdateName, UnitBook BookUpdateData);
        public List<string> GetBooksNamesData();

        public UnitBook GetBookDetailData(string bookname);
        public List<UnitBook> InsertBooksData(UnitBook insertBookData);
        public string DeleteBookData(string BookDeleteName);
    }
}
