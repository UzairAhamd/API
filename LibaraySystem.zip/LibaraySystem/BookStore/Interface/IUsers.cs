﻿using BookStore.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace BooksStore.Interfaces
{
    public interface IUsers
    {
        public List<UnitUser> GetUsersData();
        public List<UnitUser> InsertUsersData(UnitUser insertUserData);
        public string GetBookUserData(string bookname);
        public UnitUser GetUserDetailData(string username);
        public void UpdateUserData(string UserUpdateName, UnitUser UserUpdateData);
        public string IssueBookToUserData(string userID, string issueBook);
        public string DeleteBookFromUserData(string BookDeleteName);
        public string DeleteUserData(string UserDeleteID);
        public string RemoveReturnBookData(string BookReturnName);
    }
}
